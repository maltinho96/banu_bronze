# Feldornithologie-Trainer (BANU Bronze)

Lern-App fürs Handy: Artenkenntnis (Foto + Ton), äußere Topografie (antippbare Vogelzeichnungen und echte Fotos), Brutzeitcodes und Wissensfragen nach dem BANU-Fragenkatalog. Vite, ohne Framework, läuft als statische Seite auf GitHub Pages.

## Todo: Einrichten in GitHub Codespaces

1. **Repo anlegen** – auf GitHub „New repository“, z. B. `banu-trainer` (public, damit Pages kostenlos läuft).
2. **Codespace öffnen** – im Repo: *Code → Codespaces → Create codespace on main*.
3. **Dateien hochladen** – ZIP entpacken und den Inhalt per Drag & Drop in den Explorer des Codespace ziehen (inkl. der versteckten Ordner `.github` und `.devcontainer`). Alternativ im Terminal: ZIP hochladen, dann `unzip banu-trainer.zip && cp -r banu-trainer/. . && rm -r banu-trainer banu-trainer.zip`.
4. **Installieren & starten**
   ```bash
   npm install
   npm run dev
   ```
   Codespaces öffnet Port 5173 im Browser. Zum Testen am Handy: Tab *Ports* → Port 5173 → Rechtsklick → *Port Visibility → Public*, dann die URL am Handy öffnen.
5. **Artenliste:** Die 75 Arten der BANU-Liste Bronze samt Bruthabitaten (BANU-Tabelle) sind fest eingebaut in `src/data/species-builtin.js`. Lauttyp (`song`/`call`/`drumming`) steht dort ebenfalls pro Art.
6. **Bessere Tonaufnahmen holen** (behebt das „Ton passt nicht zum Vogel“-Problem am gründlichsten)
   - kostenlos bei xeno-canto.org registrieren, API-Key im Account kopieren
   - `XC_KEY=dein_key npm run fetch-audio` (dauert ca. 5–10 min, 1 Anfrage/Sekunde)
   - einzelne Art neu holen: `XC_KEY=dein_key npm run fetch-audio -- "Parus major"`
   - Ergebnis `src/data/audio.json` stichprobenartig in der App anhören (Modus *Artenliste*)
7. **GitHub Pages aktivieren** – im Repo *Settings → Pages → Build and deployment → Source: GitHub Actions*.
8. **Committen & pushen**
   ```bash
   git add -A && git commit -m "BANU-Trainer" && git push
   ```
   Unter *Actions* läuft „Auf GitHub Pages veröffentlichen“. Danach ist die App unter `https://<dein-name>.github.io/banu-trainer/` erreichbar.
9. **Aufs Handy** – URL öffnen → Teilen → *Zum Home-Bildschirm*. Startet dann wie eine App; der Lernfortschritt bleibt auf dem Gerät gespeichert.
10. **Codespace stoppen**, wenn du fertig bist (spart Freikontingent): *Code → Codespaces → … → Stop*.

## Was wo liegt

| Datei | Inhalt |
|---|---|
| `src/views/arten.js` | Artentrainer: Prüfung (30 Arten, ½ Foto, ½ Ton), Üben mit Schwachstellen-Gewichtung, Artenliste zum Durchhören, Ton-Autostart |
| `src/views/systematik.js` | Systematik: Baum, Liste, morphologische Artengruppen, Abdecken, Einordnen (Ordnung → Familie → Artengruppe), „Art nennen“ aus Ordnung/Familie/Artengruppe |
| `src/data/taxonomy.js` | wissenschaftliche Namen, Reihenfolge und Merkmale der Ordnungen und Familien; Kladogramm der Großgruppen (Galloanserae, Neoaves, Telluraves …) nach den genomischen Stammbäumen; morphologische Artengruppen (Greifvögel, Limikolen, Gründelenten …) |
| `src/views/topografie.js` | Topografie: Erkunden, „Wo ist …?“, Benennen, Am Foto, Begriffsübersicht – Bronze |
| `src/views/brutzeit.js` | Brutzeitcodes: Szenario → Code, A/B/C, Verwechslungspaare, Code → Bedeutung |
| `src/views/fragen.js` | Wissensfragen (Katalog + aus der Artenliste generiert), Brutzeitcode- und Rote-Liste-Tabellen |
| `src/data/topography.js` | Begriffe, Erklärungen, SVG-Zeichnungen (eigene, schematische) |
| `src/data/questions.js` | Fragenkatalog und Fragengeneratoren |
| `src/data/questions-extra.js` | zweiter Fragenpool – hier eigene Fragen ergänzen |
| `src/data/questions-bronze.js` | 105 Fragen nur für Bronze: Topografie, Familien und Artengruppen, Lebensräume, Recht, Brutzeitcodes |
| `src/data/brutzeit.js` | Brutzeitcodes und 45 Feldszenarien |
| `src/data/topo-examples.js` | echte Arten als Beispiel je Topografie-Begriff |
| `src/data/species-builtin.js` | BANU-Artenliste Bronze (75 Arten) mit wiss. Namen, Familie, Ordnung, Lebensraum |
| `src/lib/media.js` | Fotos (wechselnd, siehe unten), Töne (audio.json → Commons), Sperr-/Merkliste |
| `src/lib/photo-search.js` | Fotosuche über Wikidata/Commons – gemeinsam für App und `fetch-photos` |
| `scripts/` | Abruf der xeno-canto-Aufnahmen, Abruf der Fotos (`fetch-photos`) |

## Tonauswahl im Detail

1. Aufnahmen aus `src/data/audio.json` (xeno-canto, exakte Art, Qualität A/B, passender Lauttyp, bevorzugt Deutschland, ohne Jungvögel/Klangattrappe/Begleitarten).
2. Nur wenn dort < 3 Aufnahmen: Wikimedia Commons in drei Stufen – wissenschaftlicher Name im Dateinamen, dann Volltextsuche, dann deutscher Name im Dateinamen. Gewertet wird immer nur, was den Namen wirklich im Dateinamen trägt.
3. Abgespielt wird bevorzugt die mp3-Umwandlung von Commons (Safari auf dem iPhone spielt kein Ogg Vorbis), die Originaldatei liegt als zweite Quelle dahinter.
4. Die Aufnahmen wechseln: Kommt eine Art erneut dran, spielt die App reihum eine der 5 bestbewerteten Aufnahmen – jede einmal, bevor sich eine wiederholt.
5. Im Ton-Modus startet die Aufnahme beim Weiterklicken automatisch (abschaltbar in den Einstellungen des Artentrainers).

## Wechselnde Fotos im Artentrainer

Bei Fotofragen zeigt die App pro Art bis zu 5 verschiedene Bilder, reihum – erst wenn alle dran waren, geht es von vorn los (neu gemischt, ohne direkte Wiederholung).

Woher die Bilder kommen, in dieser Reihenfolge:
1. eigene Auswahl im Bild-Kurator (dieses Gerät)
2. `src/data/photos.json` im Repo
3. automatisch von Wikimedia Commons – beim ersten Mal gesucht, dann 60 Tage gemerkt
4. Notlösung: Wikipedia-Artikelbild

**Empfohlen: die Bilder einmal fest ins Repo holen**, dann haben alle Geräte sofort dieselben Fotos und die App muss nichts mehr suchen:

```bash
npm run fetch-photos                    # 5 Fotos je Art, nur Arten ohne Bilder
npm run fetch-photos -- --force         # alle neu
npm run fetch-photos -- "Turdus merula" # nur eine Art neu
git add src/data/photos.json && git commit -m "Fotos" && git push
```

Gesucht wird über Wikidata („zeigt Art X“), bevorzugt Featured- und Quality-Bilder. Aussortiert werden Eier, Nester, Küken, Präparate, Zeichnungen, Karten. Nach Möglichkeit sind Männchen und Weibchen dabei und höchstens 2 Bilder vom selben Fotografen. Urheber und Lizenz erscheinen nach dem Auflösen unter dem Foto. Einzelne unpassende Bilder lassen sich im Bild-Kurator ersetzen.

## Bilder selbst auswählen

Standardmäßig zeigt die App das Wikipedia-Artikelbild. Das passt nicht immer – im Foto-Modus der Topografie soll das Merkmal ja gut sichtbar sein.

1. In der App: *Mehr → Bilder auswählen*. Gezeigt werden nur die 19 Bronze-Merkmale.
2. Motiv antippen und beliebig viele passende Bilder auswählen. Im Training wird abwechselnd eines davon gezeigt. Drei Wege:
   - aus den Kandidaten antippen (nochmal antippen entfernt wieder),
   - *Art suchen* – eine andere Art eingeben, die das Merkmal besser zeigt (z. B. „Fitis“ für den hellen Tarsus),
   - *Link übernehmen* – Adresse einer Commons-Dateiseite, eines Wikipedia-Artikels oder direkt eines Bildes einfügen.
3. Unten *Auswahl als photos.json herunterladen* (oder in die Zwischenablage kopieren).
4. Datei als `src/data/photos.json` ins Repo legen, committen, pushen. Ab dem nächsten Deploy sieht jedes Gerät genau diese Bilder.

Im Codespace, wenn die Datei im Download-Ordner deines Rechners liegt: einfach per Drag & Drop nach `src/data/` ziehen. Alternativ die Zwischenablage nutzen und im Editor eine neue Datei `src/data/photos.json` anlegen und einfügen.

Aufbau der Datei: pro Schlüssel eine Liste von Bildern. Schlüssel sind `topo:<Begriff>` für den Foto-Modus der Topografie und `art:<wissenschaftlicher Name>` für den Artentrainer. Jedes Bild speichert `src`, `thumb`, `title`, `by` (Urheber), `lic` (Lizenz), `link` und `sp` (angezeigte Art). Weicht `sp` von der Standardart des Merkmals ab, zeigt die App den Namen der abgebildeten Art an.

## Eigene Fragen ergänzen

In `src/data/questions-extra.js` ein Objekt zu `EXTRA` hinzufügen:
```js
{ id: 'eigene-1', lv: 'b', cat: 'oek', type: 'single',
  q: 'Frage?', opts: ['richtig', 'falsch', 'falsch'], ok: [0], a: 'Erklärung.' }
```
`lv`: Stufen (`b`, `s`, `g`), `cat`: `sys`, `oek`, `leb`, `sach` oder `meth`, `type`: `single`, `multi` oder `open` (Karteikarte).

Neue Brutzeitcode-Szenarien kommen nach `src/data/brutzeit.js` in `SCENARIOS`:
```js
{ s: 'Beobachtung …', c: 'C14', x: 'Warum dieser Code und nicht der ähnliche.' }
```

Neue Foto-Beispiele für die Topografie nach `src/data/topo-examples.js`:
```js
{ term: 'Bürzel', wp: 'Mehlschwalbe', note: 'Merksatz fürs Feld.' }
```
`wp` ist der Titel des deutschen Wikipedia-Artikels, aus dem das Foto geladen wird.

## Quellen & Hinweise

- Begriffe der Topografie und Fragenstil nach den BANU-Begleitmaterialien (Morphologische Bezeichnungen 2026, Exemplarische Prüfungsfragen 2025). Die Zeichnungen sind eigene Schemazeichnungen.
- Fotos/Texte: Wikipedia. Töne: xeno-canto (Lizenz und Urheber pro Aufnahme angezeigt) und Wikimedia Commons.
- Antworten zu Recht und Ökologie sind Lernhilfen ohne Gewähr – im Zweifel die Originalquellen prüfen.
